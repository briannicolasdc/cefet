package dao;

public interface ClienteDAO {
    //colocar as funções que irão utilizar os dados aqui
    public void carregaCON();
    public void testaLimites();
    public void carregaDadosNaJanela();
}
