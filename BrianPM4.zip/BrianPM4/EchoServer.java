import java.io.File;
import java.io.FileNotFoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EchoServer extends UnicastRemoteObject implements EchoInterface {

	public EchoServer() throws RemoteException {
	}

	static List<String> buscaLinhasEmArquivo() throws FileNotFoundException {
		Scanner leitor = new Scanner(new File("tabela.csv"));
		List<String> lista = new ArrayList<String>();

		while (leitor.hasNextLine()) {
			lista.add(leitor.nextLine());
		}
		// System.out.println(lista);
		return lista;
	}

	@Override
	public String getEcho(String mensagem) throws RemoteException {
		
		String[] palavras;
		String retorno = null;
		try {
			List<String> lista = buscaLinhasEmArquivo();
			
			 for (String string : lista) {
				String linha = string;
				palavras = linha.split(";");	
			 	if (mensagem.equals(palavras[1])) {
					retorno = palavras[2];
					System.out.println(retorno);
					return retorno;
				}
			}}
		catch(FileNotFoundException e){
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		return retorno;
	}


	public static void main(String args[]) {
		EchoServer cal;

		try {
			cal = new EchoServer();
			LocateRegistry.createRegistry(1099);
			Naming.bind("rmi:///EchoServer", cal);
			System.out.println("Server Ready !");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
