//arquivo CalendarUser.java

import java.rmi.Naming;

import javax.swing.JOptionPane;


public class EchoUser
{
// constructor
public EchoUser() {}

public static void main(String args[])
{
  
EchoInterface  remoteCal;
  String vai="", volta= "";
  try {
    remoteCal = (EchoInterface) Naming.lookup("rmi:///EchoServer");
  
    do{
    vai = ""+ JOptionPane.showInputDialog("Digite o numero da matricula ou exit para sair");
    volta = remoteCal.getEcho(vai);
    JOptionPane.showMessageDialog(null, volta);
    }while(!vai.equalsIgnoreCase("Exit"));
    
  }
  
  catch (Exception e) {
      e.printStackTrace();
    }
  
    System.out.println("Fim!");
    
    
  } // main

} // class CalendarUser

