
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DAOPattern {
	public static void main(String[] args) {
		PessoalDAO dao = new PessoalDAOImpl();
		ArrayList list = new ArrayList<Pessoal>();
		list = dao.getAllPessoal();
		System.out.println(list);

	}

}

class Pessoal {

	private int matricula;
	private String nome, email, senha, cargo, turma, setor;

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getSenha() {
		return senha;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getCargo() {
		return cargo;
	}

	public String getTurma() {
		return turma;
	}

	public void setTurma(String turma) {
		this.turma = turma;
	}

	public String getSetor() {
		return setor;
	}

	public void setSetor(String setor) {
		this.setor = setor;
	}

	@Override
	public String toString() {
		return "Pessoal [matricula=" + matricula + ", nome=" + nome + ", email=" + email + ", senha=" + senha
				+ ", cargo=" + cargo + ", turma=" + turma + ", setor=" + setor + "]\n";
	}

}

interface PessoalDAO {

	public ArrayList<Pessoal> getAllPessoal();

}

class PessoalDAOImpl implements PessoalDAO {

	private ArrayList<Pessoal> list = new ArrayList<Pessoal>();
	Connection con;
	Statement st;
	ResultSet rs;

	public PessoalDAOImpl() {
		// Conexão com o driver JDBC
		String nomeJDBC = "jdbc:mysql://localhost/bd_pessoal";
		String nomeUser = "root";
		String password = "";

		try {
			con = DriverManager.getConnection(nomeJDBC, nomeUser, password);
			st = con.createStatement();
			Class.forName("com.mysql.jdbc.Driver");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {

		}
	}

	@Override
	public ArrayList<Pessoal> getAllPessoal() {

		String sql = "Select * from PESSOAL";

		try {
			st.execute(sql);
			rs = st.getResultSet();
			while (rs.next()) {
				Pessoal p = new Pessoal();
				p.setMatricula(rs.getInt("matricula"));
				p.setNome(rs.getString("nome"));
				p.setEmail(rs.getString("email"));
				p.setSenha(rs.getString("senha"));
				p.setCargo(rs.getString("cargo"));
				p.setTurma(rs.getString("turma"));
				p.setSetor(rs.getString("setor"));
				list.add(p);
			}
			con.close();
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

}
